import { createFileRoute } from '@tanstack/react-router'
import { GalleryNav } from '@/components/gallery/GalleryNav'
import { GalleryLoader } from '@/components/gallery/GalleryLoader'
import { Hero } from '@/components/gallery/Hero'
import { IntroRoom } from '@/components/gallery/IntroRoom'
import { ProjectsRoom } from '@/components/gallery/ProjectsRoom'
import { SkillsRoom } from '@/components/gallery/SkillsRoom'
import { TimelineRoom } from '@/components/gallery/TimelineRoom'
import { SummaryRoom } from '@/components/gallery/SummaryRoom'
import { ContactRoom } from '@/components/gallery/ContactRoom'
import { GalleryFooter } from '@/components/gallery/GalleryFooter'
import { profile } from '@/data/site'

export const Route = createFileRoute('/')({
  component: GreenGallery,
  head: () => ({
    meta: [
      {
        title: `${profile.name} — Green Gallery | Digital Exhibition Portfolio`,
      },
      {
        name: 'description',
        content:
          'Green Gallery — portfolio dạng phòng triển lãm học tập của sinh viên Công nghệ thông tin, trưng bày dự án, kỹ năng và hành trình phát triển.',
      },
    ],
  }),
})

function GreenGallery() {
  return (
    <div className="min-h-screen bg-[#F8FBF7] text-[#1B2B20]">
      <GalleryLoader />
      <GalleryNav />
      <main>
        <Hero />
        <IntroRoom />
        <ProjectsRoom />
        <SkillsRoom />
        <TimelineRoom />
        <SummaryRoom />
        <ContactRoom />
      </main>
      <GalleryFooter />
    </div>
  )
}
