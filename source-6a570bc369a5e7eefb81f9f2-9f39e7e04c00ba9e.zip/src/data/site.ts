// Toàn bộ nội dung của trang portfolio được tách riêng tại đây.
// Chỉ cần chỉnh sửa các giá trị bên dưới để cập nhật nội dung, không cần đụng vào giao diện.

export const profile = {
  name: 'Nguyễn Văn A',
  eyebrow: 'DIGITAL EXHIBITION',
  role: 'Sinh viên Công nghệ thông tin',
  tagline:
    'Tôi thiết kế và xây dựng những sản phẩm số gọn gàng, có chủ đích — nơi mỗi dự án là một tác phẩm được trưng bày cẩn thận, không phải một dòng trong CV.',
  school: 'Trường Đại học Bách Khoa',
  major: 'Công nghệ thông tin',
  studentId: 'B21DCCN001',
  email: 'nguyenvana@example.com',
  github: 'github.com/nguyenvana',
  portrait: '/headshot-on-white.jpg',
  ctaLabel: 'Bắt đầu tham quan',
}

export const introCards = {
  about: {
    title: 'Giới thiệu',
    body: 'Mình là sinh viên ngành Công nghệ thông tin, yêu thích việc biến những ý tưởng mơ hồ thành sản phẩm chạy được thật. Mình tin rằng một sản phẩm tốt là giao điểm giữa kỹ thuật vững và thẩm mỹ tử tế.',
  },
  interests: {
    title: 'Sở thích',
    tags: [
      'Lập trình',
      'AI',
      'Thiết kế UI',
      'Game',
      'Bóng đá',
      'Gym',
      'Cà phê',
      'Công nghệ',
    ],
  },
  direction: {
    title: 'Định hướng',
    body: 'Trở thành một Front-end / Product Engineer có tư duy thiết kế, có thể tự tay đưa một ý tưởng từ bản phác thảo đến sản phẩm hoàn chỉnh, sẵn sàng cho môi trường làm việc chuyên nghiệp.',
  },
  motto: {
    title: 'Phương châm học tập',
    body: '“Học sâu một thứ còn hơn học nông trăm thứ.” Mình ưu tiên hiểu bản chất vấn đề trước khi chạy theo công cụ mới.',
  },
}

export type Project = {
  id: string
  title: string
  curatorNote: string
  description: string
  goal: string
  techStack: Array<string>
  learned: string
  challenge: string
  improvement: string
  sourceUrl?: string
  demoUrl?: string
  pdfUrl?: string
}

export const projects: Array<Project> = [
  {
    id: 'project-01',
    title: 'Project 01 — Hệ thống quản lý học tập',
    curatorNote: 'Tác phẩm mở đầu triển lãm — nơi bắt đầu hành trình với dữ liệu và giao diện.',
    description:
      'Ứng dụng web giúp sinh viên theo dõi lịch học, deadline và điểm số theo thời gian thực.',
    goal: 'Xây dựng một công cụ quản lý học tập gọn nhẹ, dễ dùng cho sinh viên CNTT.',
    techStack: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Tailwind CSS'],
    learned: 'Thiết kế schema cơ sở dữ liệu quan hệ và xây dựng REST API từ đầu.',
    challenge: 'Đồng bộ dữ liệu thời gian thực giữa nhiều thiết bị mà không xung đột.',
    improvement: 'Áp dụng WebSocket để cập nhật tức thời thay vì polling định kỳ.',
    sourceUrl: '#',
    demoUrl: '#',
    pdfUrl: '#',
  },
  {
    id: 'project-02',
    title: 'Project 02 — Trợ lý AI cá nhân',
    curatorNote: 'Một thử nghiệm về hội thoại tự nhiên giữa người và máy.',
    description:
      'Chatbot hỗ trợ trả lời câu hỏi học tập, tóm tắt tài liệu và gợi ý lộ trình ôn tập.',
    goal: 'Tìm hiểu cách tích hợp mô hình ngôn ngữ lớn vào một sản phẩm thực tế.',
    techStack: ['Next.js', 'OpenAI API', 'LangChain', 'Vercel'],
    learned: 'Kỹ thuật prompt engineering và xử lý streaming response.',
    challenge: 'Kiểm soát chi phí gọi API khi lượng truy cập tăng đột biến.',
    improvement: 'Thêm lớp cache và giới hạn token hợp lý cho từng phiên hội thoại.',
    sourceUrl: '#',
    demoUrl: '#',
    pdfUrl: '#',
  },
  {
    id: 'project-03',
    title: 'Project 03 — Nền tảng thương mại điện tử mini',
    curatorNote: 'Tác phẩm thể hiện tư duy hệ thống và trải nghiệm mua sắm liền mạch.',
    description:
      'Website bán hàng với giỏ hàng, thanh toán và trang quản trị đơn giản cho chủ shop nhỏ.',
    goal: 'Thực hành xây dựng một hệ thống end-to-end có luồng thanh toán thật.',
    techStack: ['React', 'Express', 'MongoDB', 'Stripe'],
    learned: 'Thiết kế luồng thanh toán an toàn và quản lý trạng thái đơn hàng.',
    challenge: 'Xử lý tồn kho khi nhiều người đặt cùng một sản phẩm cùng lúc.',
    improvement: 'Dùng transaction và khóa lạc quan (optimistic locking) ở tầng dữ liệu.',
    sourceUrl: '#',
    demoUrl: '#',
    pdfUrl: '#',
  },
]

export type Skill = {
  name: string
  category: string
  level: number
  description: string
}

export const skills: Array<Skill> = [
  { name: 'Frontend', category: 'React, TypeScript, Tailwind CSS', level: 85, description: 'Xây dựng giao diện responsive, có kiến trúc component rõ ràng.' },
  { name: 'Backend', category: 'Node.js, Express, REST API', level: 70, description: 'Thiết kế API và xử lý logic nghiệp vụ phía máy chủ.' },
  { name: 'Database', category: 'PostgreSQL, MongoDB', level: 65, description: 'Mô hình hóa dữ liệu quan hệ và phi quan hệ.' },
  { name: 'UI/UX', category: 'Figma, Design System', level: 75, description: 'Thiết kế trải nghiệm người dùng và hệ thống thiết kế nhất quán.' },
  { name: 'Git', category: 'Git, GitHub, CI/CD cơ bản', level: 80, description: 'Quản lý phiên bản và làm việc nhóm trên các dự án thực tế.' },
  { name: 'AI', category: 'Prompt Engineering, LLM API', level: 60, description: 'Tích hợp mô hình AI vào sản phẩm phần mềm.' },
]

export type TimelineItem = {
  year: string
  category: 'Học tập' | 'Chứng chỉ' | 'Hoạt động' | 'Kinh nghiệm'
  title: string
  description: string
}

export const timeline: Array<TimelineItem> = [
  { year: '2021', category: 'Học tập', title: 'Nhập học ngành Công nghệ thông tin', description: 'Bắt đầu hành trình đại học với những môn nền tảng về lập trình.' },
  { year: '2022', category: 'Chứng chỉ', title: 'Chứng chỉ IELTS 6.5', description: 'Hoàn thiện năng lực tiếng Anh phục vụ đọc tài liệu chuyên ngành.' },
  { year: '2023', category: 'Hoạt động', title: 'Thành viên CLB Lập trình', description: 'Tham gia tổ chức các buổi workshop chia sẻ kiến thức lập trình web.' },
  { year: '2023', category: 'Kinh nghiệm', title: 'Thực tập sinh Front-end', description: 'Thực tập tại một công ty phần mềm, tham gia phát triển sản phẩm thực tế.' },
  { year: '2024', category: 'Chứng chỉ', title: 'Chứng chỉ AWS Cloud Practitioner', description: 'Tìm hiểu nền tảng điện toán đám mây và triển khai ứng dụng.' },
  { year: '2025', category: 'Học tập', title: 'Đồ án tốt nghiệp', description: 'Thực hiện đồ án tốt nghiệp về hệ thống web ứng dụng AI.' },
]

export const summary = {
  title: 'Phòng cuối — Tổng kết triển lãm',
  cards: [
    { title: 'Điều học được', body: 'Một sản phẩm tốt cần cả tư duy kỹ thuật lẫn con mắt thẩm mỹ — hai thứ không thể tách rời.' },
    { title: 'Khó khăn', body: 'Cân bằng giữa việc học lý thuyết trên trường và thực hành dự án cá nhân song song.' },
    { title: 'Cách vượt qua', body: 'Lập kế hoạch học tập rõ ràng, ưu tiên làm ít dự án nhưng làm sâu và hoàn thiện.' },
    { title: 'Mục tiêu tương lai', body: 'Trở thành kỹ sư phần mềm có khả năng dẫn dắt sản phẩm từ ý tưởng đến triển khai.' },
  ],
  quote: '“Thiết kế tốt là vô hình — cho đến khi bạn thử dùng thứ được thiết kế tồi.”',
}

export const contact = {
  facebook: 'facebook.com/nguyenvana',
  github: 'github.com/nguyenvana',
  linkedin: 'linkedin.com/in/nguyenvana',
  email: 'nguyenvana@example.com',
}

export const nav = [
  { id: 'room-01', label: 'Phòng 01', title: 'Giới thiệu' },
  { id: 'room-02', label: 'Phòng 02', title: 'Dự án' },
  { id: 'room-03', label: 'Phòng 03', title: 'Kỹ năng' },
  { id: 'room-04', label: 'Phòng 04', title: 'Tổng kết' },
  { id: 'contact', label: '', title: 'Liên hệ' },
]
