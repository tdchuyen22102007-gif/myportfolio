import { useEffect, useState } from 'react'
import { nav } from '@/data/site'

export function GalleryNav() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-white/70 backdrop-blur-xl border-b border-[#81C784]/25 shadow-[0_8px_30px_-15px_rgba(27,94,32,0.25)]'
          : 'bg-transparent border-b border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-10 h-20 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-3 group">
          <span className="w-9 h-9 rounded-full border-2 border-[#1B5E20] flex items-center justify-center text-[#1B5E20] font-bold text-sm transition-transform duration-300 group-hover:rotate-45">
            GG
          </span>
          <span className="font-semibold tracking-[0.2em] text-sm text-[#1B2B20]">
            GREEN GALLERY
          </span>
        </a>

        <nav className="hidden md:flex items-center gap-8">
          {nav.map((item) => (
            <a
              key={item.title}
              href={`#${item.id}`}
              className="text-sm font-medium text-[#1B2B20]/70 hover:text-[#1B5E20] transition-colors duration-300 relative group"
            >
              {item.label && <span className="text-[#81C784] mr-1.5 font-mono">{item.label}</span>}
              {item.title}
              <span className="absolute -bottom-1.5 left-0 w-0 h-px bg-[#1B5E20] transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </nav>

        <button
          onClick={() => setOpen((v) => !v)}
          className="md:hidden w-10 h-10 flex flex-col items-center justify-center gap-1.5"
          aria-label="Mở menu"
        >
          <span className={`block w-6 h-px bg-[#1B2B20] transition-transform ${open ? 'translate-y-[3px] rotate-45' : ''}`} />
          <span className={`block w-6 h-px bg-[#1B2B20] transition-opacity ${open ? 'opacity-0' : ''}`} />
          <span className={`block w-6 h-px bg-[#1B2B20] transition-transform ${open ? '-translate-y-[7px] -rotate-45' : ''}`} />
        </button>
      </div>

      {open && (
        <nav className="md:hidden bg-white/90 backdrop-blur-xl border-t border-[#81C784]/25 px-6 py-6 flex flex-col gap-5">
          {nav.map((item) => (
            <a
              key={item.title}
              href={`#${item.id}`}
              onClick={() => setOpen(false)}
              className="text-base font-medium text-[#1B2B20]"
            >
              {item.label && <span className="text-[#81C784] mr-1.5 font-mono text-sm">{item.label}</span>}
              {item.title}
            </a>
          ))}
        </nav>
      )}
    </header>
  )
}
