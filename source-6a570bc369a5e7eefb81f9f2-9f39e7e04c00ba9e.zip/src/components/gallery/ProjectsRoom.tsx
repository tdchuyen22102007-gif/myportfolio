import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { projects } from '@/data/site'
import { RoomHeader } from './RoomHeader'
import { Github, ExternalLink, FileDown, Target, Lightbulb, TriangleAlert, Wrench } from 'lucide-react'

export function ProjectsRoom() {
  const [activeId, setActiveId] = useState(projects[0].id)
  const active = projects.find((p) => p.id === activeId) ?? projects[0]

  return (
    <section id="room-02" className="relative py-28 md:py-36 bg-white">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <RoomHeader
          index="PHÒNG 02 — DỰ ÁN"
          title="Phòng trưng bày dự án"
          subtitle="Mỗi dự án là một tác phẩm được trưng bày riêng. Chọn một tác phẩm bên trái để xem ghi chú của người phụ trách triển lãm (curator)."
        />

        <div className="grid md:grid-cols-12 gap-8">
          <div className="md:col-span-4 flex md:flex-col gap-3 overflow-x-auto md:overflow-visible pb-2 md:pb-0">
            {projects.map((project, i) => (
              <button
                key={project.id}
                onClick={() => setActiveId(project.id)}
                className={`text-left shrink-0 md:shrink w-64 md:w-full rounded-2xl border px-6 py-5 transition-all duration-400 ${
                  project.id === activeId
                    ? 'bg-[#1B5E20] border-[#1B5E20] text-white shadow-[0_20px_45px_-20px_rgba(27,94,32,0.5)]'
                    : 'bg-[#F8FBF7] border-[#81C784]/25 text-[#1B2B20] hover:border-[#1B5E20]/40'
                }`}
              >
                <span
                  className={`block text-[11px] font-mono tracking-widest mb-1 ${
                    project.id === activeId ? 'text-[#A5D6A7]' : 'text-[#1B5E20]/60'
                  }`}
                >
                  {String(i + 1).padStart(2, '0')}
                </span>
                <span className="block font-semibold leading-snug">{project.title}</span>
              </button>
            ))}
          </div>

          <div className="md:col-span-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={active.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -16 }}
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                className="rounded-3xl border border-[#81C784]/25 bg-[#F8FBF7] p-8 md:p-10 shadow-[0_30px_70px_-35px_rgba(27,94,32,0.3)]"
              >
                <p className="text-xs font-semibold tracking-widest text-[#1B5E20] mb-3">CURATOR NOTE</p>
                <p className="italic text-[#1B2B20]/70 mb-6">{active.curatorNote}</p>

                <h3 className="text-2xl md:text-3xl font-extrabold text-[#1B2B20] mb-4">{active.title}</h3>
                <p className="text-[#1B2B20]/75 leading-relaxed mb-8">{active.description}</p>

                <div className="grid sm:grid-cols-2 gap-5 mb-8">
                  <DetailBlock icon={<Target size={16} />} label="Mục tiêu" value={active.goal} />
                  <DetailBlock icon={<Lightbulb size={16} />} label="Điểm học được" value={active.learned} />
                  <DetailBlock icon={<TriangleAlert size={16} />} label="Khó khăn" value={active.challenge} />
                  <DetailBlock icon={<Wrench size={16} />} label="Cách cải thiện" value={active.improvement} />
                </div>

                <div className="mb-8">
                  <p className="text-xs font-semibold tracking-widest text-[#1B2B20]/50 mb-3">CÔNG NGHỆ SỬ DỤNG</p>
                  <div className="flex flex-wrap gap-2">
                    {active.techStack.map((tech) => (
                      <span
                        key={tech}
                        className="px-3 py-1 rounded-full text-xs font-medium bg-white border border-[#81C784]/30 text-[#1B5E20]"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex flex-wrap gap-3">
                  {active.sourceUrl && (
                    <a href={active.sourceUrl} className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-[#1B2B20] text-white text-sm font-semibold hover:bg-black transition-colors">
                      <Github size={16} /> Xem Source Code
                    </a>
                  )}
                  {active.demoUrl && (
                    <a href={active.demoUrl} className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-[#1B5E20] text-white text-sm font-semibold hover:bg-[#164a1a] transition-colors">
                      <ExternalLink size={16} /> Xem Demo
                    </a>
                  )}
                  {active.pdfUrl && (
                    <a href={active.pdfUrl} className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-[#1B5E20]/30 text-[#1B5E20] text-sm font-semibold hover:bg-[#A5D6A7]/20 transition-colors">
                      <FileDown size={16} /> Tải PDF
                    </a>
                  )}
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  )
}

function DetailBlock({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-xl bg-white border border-[#81C784]/20 p-4">
      <p className="flex items-center gap-2 text-xs font-semibold tracking-wide text-[#1B5E20] mb-1.5">
        {icon} {label}
      </p>
      <p className="text-sm text-[#1B2B20]/75 leading-relaxed">{value}</p>
    </div>
  )
}
