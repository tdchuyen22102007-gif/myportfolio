import { motion } from 'framer-motion'
import { profile } from '@/data/site'
import { Mail, GraduationCap, Hash, Github, ArrowDown } from 'lucide-react'

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-32 pb-24 md:pt-40 md:pb-32">
      {/* background geometry */}
      <div aria-hidden className="pointer-events-none absolute inset-0 select-none">
        <span className="absolute -top-10 -left-24 w-[26rem] h-[26rem] rounded-full border border-[#81C784]/30" />
        <span className="absolute top-1/3 right-[-8rem] w-96 h-96 rounded-full bg-[#A5D6A7]/15 blur-3xl animate-float-slow" />
        <span className="absolute bottom-0 left-1/4 w-72 h-72 rotate-12 border border-[#1B5E20]/15 animate-float-slower" />
        <span className="absolute top-24 right-1/4 w-24 h-24 rotate-45 border border-[#81C784]/25" />
        <span className="absolute top-1/2 left-0 w-1/3 h-px bg-gradient-to-r from-transparent via-[#1B5E20]/20 to-transparent" />
        <p className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[16vw] md:text-[11rem] font-black tracking-tighter text-[#1B5E20]/[0.04] whitespace-nowrap select-none leading-none">
          GREEN GALLERY
        </p>
      </div>

      <div className="relative max-w-7xl mx-auto px-6 md:px-10 grid md:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, x: -32 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="relative mx-auto max-w-sm md:max-w-none"
        >
          <div className="absolute -inset-4 rounded-[2.5rem] border border-[#81C784]/30" />
          <div className="absolute -inset-8 rounded-[3rem] border border-[#81C784]/15" />
          <div className="relative rounded-[2rem] overflow-hidden bg-white p-3 shadow-[0_40px_80px_-30px_rgba(27,94,32,0.35)] gallery-border-gradient">
            <div className="rounded-[1.5rem] overflow-hidden aspect-[4/5]">
              <img
                src={profile.portrait}
                alt={profile.name}
                className="w-full h-full object-cover grayscale-[15%] contrast-105"
              />
            </div>
            <div className="absolute bottom-6 left-6 right-6 glass-panel rounded-xl px-4 py-2 border border-white/50">
              <p className="text-[10px] tracking-[0.25em] font-semibold text-[#1B5E20]">
                {profile.eyebrow}
              </p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
        >
          <p className="text-xs md:text-sm font-semibold tracking-[0.35em] text-[#1B5E20] mb-5">
            {profile.eyebrow}
          </p>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-[#1B2B20] leading-[1.02] mb-6">
            {profile.name}
          </h1>
          <p className="text-base md:text-lg text-[#1B2B20]/70 max-w-lg mb-8 leading-relaxed">
            {profile.tagline}
          </p>

          <div className="glass-panel border border-[#81C784]/25 rounded-2xl p-5 mb-9 grid grid-cols-2 gap-4 max-w-md shadow-[0_20px_50px_-30px_rgba(27,94,32,0.3)]">
            <InfoRow icon={<GraduationCap size={15} />} label="Trường" value={profile.school} />
            <InfoRow icon={<Hash size={15} />} label="MSSV" value={profile.studentId} />
            <InfoRow icon={<GraduationCap size={15} />} label="Ngành" value={profile.major} />
            <InfoRow icon={<Mail size={15} />} label="Email" value={profile.email} />
            <InfoRow icon={<Github size={15} />} label="GitHub" value={profile.github} />
          </div>

          <a
            href="#room-01"
            className="inline-flex items-center gap-2 bg-[#1B5E20] text-white px-8 py-4 rounded-full text-sm font-semibold tracking-wide shadow-[0_20px_40px_-15px_rgba(27,94,32,0.5)] hover:bg-[#164a1a] hover:-translate-y-0.5 transition-all duration-300"
          >
            {profile.ctaLabel}
            <ArrowDown size={16} className="animate-bounce" />
          </a>
        </motion.div>
      </div>
    </section>
  )
}

function InfoRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-start gap-2 min-w-0">
      <span className="text-[#1B5E20] mt-0.5 shrink-0">{icon}</span>
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-wider text-[#1B2B20]/45">{label}</p>
        <p className="text-sm font-medium text-[#1B2B20] truncate">{value}</p>
      </div>
    </div>
  )
}
