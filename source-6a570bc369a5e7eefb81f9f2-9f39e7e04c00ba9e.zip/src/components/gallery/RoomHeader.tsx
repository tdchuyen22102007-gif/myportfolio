import { Reveal } from './Reveal'

export function RoomHeader({
  index,
  title,
  subtitle,
}: {
  index: string
  title: string
  subtitle?: string
}) {
  return (
    <Reveal className="mb-14 md:mb-20 max-w-3xl">
      <p className="text-xs font-semibold tracking-[0.35em] text-[#1B5E20] mb-4 flex items-center gap-3">
        <span className="w-8 h-px bg-[#1B5E20]" />
        {index}
      </p>
      <h2 className="text-4xl md:text-6xl font-extrabold tracking-tight text-[#1B2B20] mb-4 leading-[1.05]">
        {title}
      </h2>
      {subtitle && <p className="text-base md:text-lg text-[#1B2B20]/60 leading-relaxed">{subtitle}</p>}
    </Reveal>
  )
}
