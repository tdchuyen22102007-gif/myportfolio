import { summary } from '@/data/site'
import { Reveal } from './Reveal'

export function SummaryRoom() {
  return (
    <section id="room-04" className="relative py-28 md:py-36 bg-[#1B5E20] text-white overflow-hidden">
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <span className="absolute top-0 right-0 w-96 h-96 rounded-full bg-white/5 blur-3xl" />
        <span className="absolute bottom-0 left-0 w-72 h-72 rounded-full bg-[#A5D6A7]/10 blur-3xl" />
      </div>

      <div className="relative max-w-6xl mx-auto px-6 md:px-10">
        <Reveal className="mb-16 max-w-2xl">
          <p className="text-xs font-semibold tracking-[0.35em] text-[#A5D6A7] mb-4 flex items-center gap-3">
            <span className="w-8 h-px bg-[#A5D6A7]" />
            PHÒNG 04 — TỔNG KẾT
          </p>
          <h2 className="text-4xl md:text-6xl font-extrabold tracking-tight leading-[1.05]">{summary.title}</h2>
        </Reveal>

        <div className="grid sm:grid-cols-2 gap-6 mb-20">
          {summary.cards.map((card, i) => (
            <Reveal key={card.title} delay={i * 0.06}>
              <div className="rounded-3xl border border-white/15 bg-white/5 backdrop-blur-sm p-7 h-full hover:bg-white/10 transition-colors duration-500">
                <h3 className="text-lg font-bold mb-3 text-[#A5D6A7]">{card.title}</h3>
                <p className="text-white/75 leading-relaxed">{card.body}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.2}>
          <blockquote className="text-2xl md:text-4xl font-semibold leading-snug max-w-4xl">
            {summary.quote}
          </blockquote>
        </Reveal>
      </div>
    </section>
  )
}
