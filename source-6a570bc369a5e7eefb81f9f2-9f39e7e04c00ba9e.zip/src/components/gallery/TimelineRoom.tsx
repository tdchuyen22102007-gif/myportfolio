import { timeline } from '@/data/site'
import { Reveal } from './Reveal'
import { RoomHeader } from './RoomHeader'

const badgeColors: Record<string, string> = {
  'Học tập': 'bg-[#1B5E20] text-white',
  'Chứng chỉ': 'bg-[#81C784] text-[#1B2B20]',
  'Hoạt động': 'bg-[#A5D6A7] text-[#1B2B20]',
  'Kinh nghiệm': 'bg-[#1B2B20] text-white',
}

export function TimelineRoom() {
  return (
    <section className="relative py-28 md:py-36 bg-white">
      <div className="max-w-5xl mx-auto px-6 md:px-10">
        <RoomHeader
          index="HÀNH LANG KÝ ỨC"
          title="Dòng thời gian trưởng thành"
          subtitle="Những cột mốc học tập, chứng chỉ, hoạt động và kinh nghiệm đã đi qua."
        />

        <div className="relative pl-8 md:pl-10">
          <div className="absolute left-0 top-2 bottom-2 w-px bg-gradient-to-b from-[#1B5E20] via-[#81C784]/50 to-transparent" />

          <div className="space-y-12">
            {timeline.map((item, i) => (
              <Reveal key={i} delay={i * 0.05} y={20}>
                <div className="relative">
                  <span className="absolute -left-[2.55rem] md:-left-[2.85rem] top-1 w-3.5 h-3.5 rounded-full bg-[#1B5E20] ring-4 ring-[#A5D6A7]/30" />
                  <div className="flex flex-wrap items-center gap-3 mb-2">
                    <span className="text-sm font-mono font-semibold text-[#1B5E20]">{item.year}</span>
                    <span className={`text-[10px] font-semibold tracking-wide px-2.5 py-1 rounded-full ${badgeColors[item.category]}`}>
                      {item.category}
                    </span>
                  </div>
                  <h3 className="text-lg md:text-xl font-bold text-[#1B2B20] mb-1.5">{item.title}</h3>
                  <p className="text-[#1B2B20]/65 leading-relaxed max-w-2xl">{item.description}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
