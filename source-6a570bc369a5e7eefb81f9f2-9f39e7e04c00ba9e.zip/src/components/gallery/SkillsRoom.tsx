import { skills } from '@/data/site'
import { Reveal } from './Reveal'
import { RoomHeader } from './RoomHeader'
import { Code2, Server, Database, Palette, GitBranch, BrainCircuit } from 'lucide-react'

const icons: Record<string, React.ReactNode> = {
  Frontend: <Code2 size={22} />,
  Backend: <Server size={22} />,
  Database: <Database size={22} />,
  'UI/UX': <Palette size={22} />,
  Git: <GitBranch size={22} />,
  AI: <BrainCircuit size={22} />,
}

export function SkillsRoom() {
  return (
    <section id="room-03" className="relative py-28 md:py-36 bg-[#F8FBF7]">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <RoomHeader
          index="PHÒNG 03 — KỸ NĂNG"
          title="Bộ công cụ của người kiến tạo"
          subtitle="Những năng lực kỹ thuật được rèn luyện qua từng dự án trong triển lãm này."
        />

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {skills.map((skill, i) => (
            <Reveal key={skill.name} delay={i * 0.06}>
              <div className="group rounded-3xl border border-[#81C784]/25 bg-white p-7 h-full hover:-translate-y-1.5 hover:shadow-[0_30px_60px_-30px_rgba(27,94,32,0.3)] shadow-[0_15px_40px_-30px_rgba(27,94,32,0.2)] transition-all duration-500">
                <div className="w-12 h-12 rounded-2xl bg-[#1B5E20] text-white flex items-center justify-center mb-5 group-hover:rotate-6 transition-transform duration-500">
                  {icons[skill.name]}
                </div>
                <h3 className="text-lg font-bold text-[#1B2B20] mb-1">{skill.name}</h3>
                <p className="text-xs text-[#1B2B20]/45 mb-5">{skill.category}</p>

                <div className="h-1.5 rounded-full bg-[#A5D6A7]/25 overflow-hidden mb-2">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-[#1B5E20] to-[#81C784] transition-all duration-1000"
                    style={{ width: `${skill.level}%` }}
                  />
                </div>
                <p className="text-right text-xs font-semibold text-[#1B5E20] mb-4">{skill.level}%</p>

                <p className="text-sm text-[#1B2B20]/65 leading-relaxed">{skill.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
