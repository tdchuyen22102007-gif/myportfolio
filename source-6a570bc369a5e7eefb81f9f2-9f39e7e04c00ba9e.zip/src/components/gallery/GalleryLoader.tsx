import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'

export function GalleryLoader() {
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 900)
    return () => clearTimeout(timer)
  }, [])

  return (
    <AnimatePresence>
      {loading && (
        <motion.div
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: 'easeInOut' }}
          className="fixed inset-0 z-[100] bg-[#1B5E20] flex flex-col items-center justify-center"
        >
          <motion.span
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="text-white text-2xl font-bold tracking-[0.3em] mb-6"
          >
            GG
          </motion.span>
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: 160 }}
            transition={{ duration: 0.8, ease: 'easeInOut' }}
            className="h-px bg-[#A5D6A7]"
          />
        </motion.div>
      )}
    </AnimatePresence>
  )
}
