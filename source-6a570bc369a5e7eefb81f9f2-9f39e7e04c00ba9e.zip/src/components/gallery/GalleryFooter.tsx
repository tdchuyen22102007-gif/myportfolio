export function GalleryFooter() {
  return (
    <footer className="bg-white border-t border-[#81C784]/20 py-8">
      <div className="max-w-7xl mx-auto px-6 md:px-10 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-[#1B2B20]/50">
        <p>© {new Date().getFullYear()} Green Gallery. Đã bước qua đủ 4 phòng triển lãm.</p>
        <p className="tracking-widest text-xs font-medium text-[#1B5E20]">GREEN GALLERY</p>
      </div>
    </footer>
  )
}
