import { introCards } from '@/data/site'
import { Reveal } from './Reveal'
import { RoomHeader } from './RoomHeader'
import { Sparkles, Compass, BookOpen } from 'lucide-react'

const cardBase =
  'relative rounded-3xl border border-[#81C784]/25 bg-white p-8 shadow-[0_25px_60px_-35px_rgba(27,94,32,0.25)] hover:-translate-y-1.5 hover:shadow-[0_35px_70px_-30px_rgba(27,94,32,0.35)] transition-all duration-500'

export function IntroRoom() {
  return (
    <section id="room-01" className="relative py-28 md:py-36 bg-[#F8FBF7]">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <RoomHeader
          index="PHÒNG 01 — GIỚI THIỆU"
          title="Chân dung một người làm sản phẩm"
          subtitle="Một góc nhìn ngắn gọn về con người, sở thích và định hướng đằng sau những dự án được trưng bày trong triển lãm này."
        />

        <div className="grid md:grid-cols-6 gap-6">
          <Reveal className="md:col-span-4" delay={0.05}>
            <div className={cardBase + ' h-full'}>
              <Sparkles className="text-[#1B5E20] mb-5" size={26} />
              <h3 className="text-2xl font-bold text-[#1B2B20] mb-3">{introCards.about.title}</h3>
              <p className="text-[#1B2B20]/70 leading-relaxed">{introCards.about.body}</p>
            </div>
          </Reveal>

          <Reveal className="md:col-span-2" delay={0.1}>
            <div className={cardBase + ' h-full bg-[#1B5E20] border-none text-white'}>
              <Compass className="mb-5" size={26} />
              <h3 className="text-xl font-bold mb-3">{introCards.direction.title}</h3>
              <p className="text-white/80 leading-relaxed text-sm">{introCards.direction.body}</p>
            </div>
          </Reveal>

          <Reveal className="md:col-span-3" delay={0.15}>
            <div className={cardBase + ' h-full'}>
              <h3 className="text-xl font-bold text-[#1B2B20] mb-5">{introCards.interests.title}</h3>
              <div className="flex flex-wrap gap-2.5">
                {introCards.interests.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-4 py-1.5 rounded-full text-sm font-medium bg-[#A5D6A7]/25 text-[#1B5E20] border border-[#81C784]/30 hover:bg-[#A5D6A7]/45 transition-colors duration-300"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </Reveal>

          <Reveal className="md:col-span-3" delay={0.2}>
            <div className={cardBase + ' h-full'}>
              <BookOpen className="text-[#1B5E20] mb-5" size={26} />
              <h3 className="text-xl font-bold text-[#1B2B20] mb-3">{introCards.motto.title}</h3>
              <p className="text-[#1B2B20]/70 leading-relaxed italic">{introCards.motto.body}</p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
