import { contact, profile } from '@/data/site'
import { Reveal } from './Reveal'
import { Facebook, Github, Linkedin, Mail } from 'lucide-react'

export function ContactRoom() {
  return (
    <section id="contact" className="relative py-28 md:py-36 bg-[#F8FBF7]">
      <div className="max-w-4xl mx-auto px-6 md:px-10 text-center">
        <Reveal>
          <p className="text-xs font-semibold tracking-[0.35em] text-[#1B5E20] mb-4">LỐI RA — LIÊN HỆ</p>
          <h2 className="text-4xl md:text-6xl font-extrabold tracking-tight text-[#1B2B20] mb-6 leading-[1.05]">
            Cùng xây dựng điều gì đó
          </h2>
          <p className="text-[#1B2B20]/65 max-w-xl mx-auto mb-14 leading-relaxed">
            Cảm ơn bạn đã ghé thăm triển lãm. Nếu có một cơ hội hợp tác hay đơn giản là một lời chào, đừng ngần ngại liên hệ.
          </p>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="rounded-3xl border border-[#81C784]/25 bg-white p-8 md:p-10 shadow-[0_30px_70px_-35px_rgba(27,94,32,0.3)] gallery-border-gradient">
            <div className="grid sm:grid-cols-2 gap-4 mb-8 text-left">
              <ContactRow icon={<Mail size={17} />} label="Email" value={contact.email} />
              <ContactRow icon={<Github size={17} />} label="GitHub" value={contact.github} />
              <ContactRow icon={<Linkedin size={17} />} label="LinkedIn" value={contact.linkedin} />
              <ContactRow icon={<Facebook size={17} />} label="Facebook" value={contact.facebook} />
            </div>

            <a
              href={`mailto:${profile.email}`}
              className="inline-flex items-center gap-2 bg-[#1B5E20] text-white px-9 py-4 rounded-full text-sm font-semibold tracking-wide shadow-[0_20px_40px_-15px_rgba(27,94,32,0.5)] hover:bg-[#164a1a] hover:-translate-y-0.5 transition-all duration-300"
            >
              Liên hệ với tôi
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  )
}

function ContactRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3 rounded-xl bg-[#F8FBF7] border border-[#81C784]/20 px-4 py-3">
      <span className="w-9 h-9 rounded-full bg-[#A5D6A7]/25 text-[#1B5E20] flex items-center justify-center shrink-0">
        {icon}
      </span>
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-wider text-[#1B2B20]/45">{label}</p>
        <p className="text-sm font-medium text-[#1B2B20] truncate">{value}</p>
      </div>
    </div>
  )
}
